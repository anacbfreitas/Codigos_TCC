%% Inicializa
clc;
clear;

% Vari�vel de Laplace
s = tf('s');

% Formato de apresentacao
format long e

%% Planta

% Par�metros fornecidos
R = 0.05;
Trv = 0.2;
Tt = 0.5;
M = 10;
D = 2;
B = 4309.933333;

% FT da regulacao primaria
Num_prim = R;
Den_prim = ( R * (1 + s*Trv) * (1 + s*Tt) * (M*s + D) + 1 );
Gprim = Num_prim / Den_prim

% Raizes da FT do primario
[~, Den_prim_vet] = tfdata(Gprim, 'v');
raizes = roots(Den_prim_vet)

figure;
rlocus(Gprim*B);

figure;
step(Gprim);

% Pega um dos valores reais
Zcont = 0;
for i = 1:length(raizes)
    if(isreal(raizes(i)))
        Zcont = raizes(i);
    end
end

%% Lugar das raizes do Controlador P

H = B;

C_P_unit = 1;

GH_rlocus = C_P_unit * Gprim * H;

figure;
rlocus(GH_rlocus);

%% Lugar das raizes do Controlador I

H = B;

C_I_unit = 1/s;

GH_rlocus = C_I_unit * Gprim * H;

figure;
rlocus(GH_rlocus);

%% Lugar das raizes do Controlador PI

H = B;

z = 0.5;

C_PI_unit = (s+z)/s;
GH_rlocus = C_PI_unit * Gprim * H;

figure;
rlocus(GH_rlocus);


